extends Control

func _on_confirm_button_pressed() -> void:
    get_tree().change_scene_to_file("res://scenes/MainMatch.tscn")

func _on_back_button_pressed() -> void:
    get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

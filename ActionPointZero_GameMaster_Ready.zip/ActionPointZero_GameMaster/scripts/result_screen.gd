extends Control

func show_result(winning_player: int) -> void:
    var result_label: Label = $CenterContainer/Panel/VBoxContainer/ResultLabel
    if winning_player == 1:
        result_label.text = "PLAYER 1 WINS!"
    elif winning_player == 2:
        result_label.text = "PLAYER 2 WINS!"
    else:
        result_label.text = "GAME OVER"

func _on_rematch_button_pressed() -> void:
    GameManager.reset_match()
    get_tree().change_scene_to_file("res://scenes/MainMatch.tscn")

func _on_main_menu_button_pressed() -> void:
    get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

extends Node
## Central rules/UI-facing manager for Role 2: The Game Master.
## Based on the supplied Action Point Zero game design document.

signal ap_changed(current_ap: int)
signal turn_changed(player: int, round: int)
signal ultimate_status_changed(available: bool)
signal game_over(winner: int)
signal message_changed(message: String)

const TURN_AP := 5
const MAX_UNIT_AP := 3
const MOVEMENT_AP := 1
const ATTACK_AP := 2
const ULTIMATE_AP := 3

var current_player: int = 1
var round_number: int = 1
var action_points: int = TURN_AP
var ultimate_used_this_turn: bool = false
var game_over_state: bool = false
var winner: int = 0
var unit_ap_spent: Dictionary = {}
var units: Dictionary = {}

func _ready() -> void:
    start_match()

func start_match() -> void:
    current_player = 1
    round_number = 1
    action_points = TURN_AP
    ultimate_used_this_turn = false
    game_over_state = false
    winner = 0
    unit_ap_spent.clear()
    units.clear()

    for unit_name in ["Sniper", "Infantry", "Cavalry", "Medic", "Chemist"]:
        register_unit("P1_" + unit_name, 1)
        register_unit("P2_" + unit_name, 2)

    _emit_state()
    message_changed.emit("Match started. Player 1 has 5 AP.")

func reset_match() -> void:
    start_match()

func spend_ap(amount: int) -> bool:
    if game_over_state or amount <= 0:
        return false
    if action_points < amount:
        message_changed.emit("Not enough AP.")
        return false
    action_points -= amount
    ap_changed.emit(action_points)
    ultimate_status_changed.emit(can_use_ultimate())
    return true

func spend_unit_ap(unit_id: String, amount: int) -> bool:
    if game_over_state or amount <= 0:
        return false
    if not units.has(unit_id):
        message_changed.emit("Unknown unit: " + unit_id)
        return false
    if not _is_current_players_unit(unit_id):
        message_changed.emit("It is not your turn to control " + unit_id + ".")
        return false

    var used: int = int(unit_ap_spent.get(unit_id, 0))
    if used + amount > MAX_UNIT_AP:
        message_changed.emit(unit_id + " cannot spend more than 3 AP this turn.")
        return false
    if action_points < amount:
        message_changed.emit("Not enough global AP.")
        return false

    action_points -= amount
    unit_ap_spent[unit_id] = used + amount
    _emit_state()
    message_changed.emit(unit_id + " spent " + str(amount) + " AP.")
    return true

func perform_movement(unit_id: String) -> bool:
    return spend_unit_ap(unit_id, MOVEMENT_AP)

func perform_standard_attack(unit_id: String) -> bool:
    return spend_unit_ap(unit_id, ATTACK_AP)

func can_use_ultimate() -> bool:
    if game_over_state:
        return false
    if round_number < 4:
        return false
    if ultimate_used_this_turn:
        return false
    if action_points < ULTIMATE_AP:
        return false
    return true

func use_ultimate(unit_id: String) -> bool:
    if not can_use_ultimate():
        if round_number < 4:
            message_changed.emit("Ultimates unlock in Round 4.")
        elif ultimate_used_this_turn:
            message_changed.emit("Only one Ultimate can be used per turn.")
        else:
            message_changed.emit("Not enough AP for an Ultimate.")
        return false

    if not units.has(unit_id):
        message_changed.emit("Unknown unit: " + unit_id)
        return false
    if not _is_current_players_unit(unit_id):
        message_changed.emit("It is not your turn to control " + unit_id + ".")
        return false

    var used: int = int(unit_ap_spent.get(unit_id, 0))
    if used + ULTIMATE_AP > MAX_UNIT_AP:
        message_changed.emit(unit_id + " has already spent AP this turn.")
        return false

    action_points -= ULTIMATE_AP
    unit_ap_spent[unit_id] = used + ULTIMATE_AP
    ultimate_used_this_turn = true
    _emit_state()
    message_changed.emit(unit_id + " used their Ultimate.")
    return true

func end_turn() -> void:
    if game_over_state:
        return

    if current_player == 1:
        current_player = 2
    else:
        current_player = 1
        round_number += 1

    action_points = TURN_AP
    unit_ap_spent.clear()
    ultimate_used_this_turn = false
    _emit_state()
    message_changed.emit("Player " + str(current_player) + " Turn - 5 AP")

func register_unit(unit_id: String, player_id: int) -> void:
    units[unit_id] = {
        "player": player_id,
        "alive": true
    }

func set_unit_alive(unit_id: String, alive: bool) -> void:
    if not units.has(unit_id):
        return
    units[unit_id]["alive"] = alive
    check_win_condition()

func is_unit_alive(unit_id: String) -> bool:
    return bool(units.get(unit_id, {}).get("alive", false))

func get_unit_ap_spent(unit_id: String) -> int:
    return int(unit_ap_spent.get(unit_id, 0))

func get_alive_count(player_id: int) -> int:
    var count := 0
    for unit_id in units:
        if int(units[unit_id]["player"]) == player_id and bool(units[unit_id]["alive"]):
            count += 1
    return count

func check_win_condition() -> void:
    if game_over_state:
        return

    var p1_alive := get_alive_count(1) > 0
    var p2_alive := get_alive_count(2) > 0

    if p1_alive and not p2_alive:
        _finish_game(1)
    elif p2_alive and not p1_alive:
        _finish_game(2)

func _finish_game(winning_player: int) -> void:
    game_over_state = true
    winner = winning_player
    message_changed.emit("Total Tactical Annihilation: Player " + str(winning_player) + " wins!")
    game_over.emit(winner)

func is_game_over() -> bool:
    return game_over_state

func get_winner() -> int:
    return winner

func _is_current_players_unit(unit_id: String) -> bool:
    return int(units[unit_id]["player"]) == current_player

func _emit_state() -> void:
    ap_changed.emit(action_points)
    turn_changed.emit(current_player, round_number)
    ultimate_status_changed.emit(can_use_ultimate())

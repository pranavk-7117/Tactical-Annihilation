extends Control

@onready var ap_label: Label = $MarginContainer/VBoxContainer/TopBar/APLabel
@onready var turn_label: Label = $MarginContainer/VBoxContainer/TopBar/TurnLabel
@onready var round_label: Label = $MarginContainer/VBoxContainer/TopBar/RoundLabel
@onready var ultimate_button: Button = $MarginContainer/VBoxContainer/ActionBar/UltimateButton
@onready var end_turn_button: Button = $MarginContainer/VBoxContainer/ActionBar/EndTurnButton
@onready var message_label: Label = $MarginContainer/VBoxContainer/MessageLabel
@onready var unit_option: OptionButton = $MarginContainer/VBoxContainer/UnitRow/UnitOptionButton
@onready var unit_ap_label: Label = $MarginContainer/VBoxContainer/UnitRow/UnitAPLabel
@onready var p1_status: Label = $MarginContainer/VBoxContainer/StatusPanel/P1Status
@onready var p2_status: Label = $MarginContainer/VBoxContainer/StatusPanel/P2Status

var unit_ids := [
    "P1_Sniper", "P1_Infantry", "P1_Cavalry", "P1_Medic", "P1_Chemist",
    "P2_Sniper", "P2_Infantry", "P2_Cavalry", "P2_Medic", "P2_Chemist"
]

func _ready() -> void:
    GameManager.ap_changed.connect(_on_ap_changed)
    GameManager.turn_changed.connect(_on_turn_changed)
    GameManager.ultimate_status_changed.connect(_on_ultimate_status_changed)
    GameManager.message_changed.connect(_on_message_changed)
    GameManager.game_over.connect(_on_game_over)
    _populate_units()
    _refresh_all()

func _populate_units() -> void:
    unit_option.clear()
    for unit_id in unit_ids:
        unit_option.add_item(unit_id)

func _refresh_all() -> void:
    ap_label.text = "AP: " + str(GameManager.action_points) + " / 5"
    turn_label.text = "Player " + str(GameManager.current_player) + " Turn"
    round_label.text = "Round " + str(GameManager.round_number)
    ultimate_button.disabled = not GameManager.can_use_ultimate()
    unit_ap_label.text = "Unit AP: 0 / 3"
    p1_status.text = "Player 1 Alive: " + str(GameManager.get_alive_count(1)) + " / 5"
    p2_status.text = "Player 2 Alive: " + str(GameManager.get_alive_count(2)) + " / 5"

func _selected_unit_id() -> String:
    if unit_option.selected < 0:
        return ""
    return unit_option.get_item_text(unit_option.selected)

func _refresh_selected_unit() -> void:
    var unit_id := _selected_unit_id()
    if unit_id == "":
        unit_ap_label.text = "Unit AP: - / 3"
    else:
        unit_ap_label.text = "Unit AP: " + str(GameManager.get_unit_ap_spent(unit_id)) + " / 3"

func _on_ap_changed(current_ap: int) -> void:
    ap_label.text = "AP: " + str(current_ap) + " / 5"
    _refresh_selected_unit()

func _on_turn_changed(player: int, round: int) -> void:
    turn_label.text = "Player " + str(player) + " Turn"
    round_label.text = "Round " + str(round)
    _refresh_all()

func _on_ultimate_status_changed(available: bool) -> void:
    ultimate_button.disabled = not available

func _on_message_changed(message: String) -> void:
    message_label.text = message
    _refresh_all()

func _on_unit_option_button_item_selected(_index: int) -> void:
    _refresh_selected_unit()

func _on_move_button_pressed() -> void:
    var unit_id := _selected_unit_id()
    if unit_id != "":
        GameManager.perform_movement(unit_id)

func _on_attack_button_pressed() -> void:
    var unit_id := _selected_unit_id()
    if unit_id != "":
        GameManager.perform_standard_attack(unit_id)

func _on_ultimate_button_pressed() -> void:
    var unit_id := _selected_unit_id()
    if unit_id != "":
        GameManager.use_ultimate(unit_id)

func _on_end_turn_button_pressed() -> void:
    GameManager.end_turn()

func _on_kill_p1_button_pressed() -> void:
    _kill_next_alive(1)

func _on_kill_p2_button_pressed() -> void:
    _kill_next_alive(2)

func _kill_next_alive(player_id: int) -> void:
    for unit_id in unit_ids:
        if unit_id.begins_with("P" + str(player_id) + "_") and GameManager.is_unit_alive(unit_id):
            GameManager.set_unit_alive(unit_id, false)
            _refresh_all()
            return

func _on_game_over(winning_player: int) -> void:
    var result_scene = load("res://scenes/ResultScreen.tscn").instantiate()
    get_tree().root.add_child(result_scene)
    result_scene.show_result(winning_player)

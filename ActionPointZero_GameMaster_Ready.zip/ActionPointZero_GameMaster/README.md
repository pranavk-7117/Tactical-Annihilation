# Action Point Zero — Role 2: The Game Master

This package is a ready-to-open Godot 4 prototype for the Game Master role.

## What works immediately

The project uses `scripts/game_manager.gd` as an autoload, so you can open the project in Godot and press Play without compiling C++.

Implemented:
- 5 AP every turn
- 3 AP maximum per unit per turn
- Movement = 1 AP
- Standard attack = 2 AP
- Ultimate = 3 AP
- Ultimates locked in Rounds 1–3
- Only one Ultimate per turn from Round 4 onward
- Two-player turn switching
- Round increments after Player 2 finishes
- 5 units per player
- Total Tactical Annihilation win condition
- Main menu, roster screen, match HUD, result screen

## Quick test

1. Install/open Godot 4.x.
2. Import this folder as a project.
3. Press Play.
4. Start Game -> Confirm Squad.
5. In the match, select a unit and test Move/Attack/Ultimate/End Turn.
6. Use the debug buttons at the bottom to eliminate Player 1 or Player 2 units and demonstrate the win condition.
7. End turns until Round 4 to test Ultimate unlock.

## C++ version

The `cpp/` folder contains the same GameManager logic as a GDExtension source.

To build it, install `godot-cpp` matching your Godot 4.x version and SCons, then build with the `GODOT_CPP_PATH` environment variable pointing at your `godot-cpp` checkout. The supplied `.gdextension` file expects the resulting dylib at `res://bin/libgame_master.macos.dylib`.

For your OOPS CP presentation, explain that the GDScript implementation is the immediately runnable prototype, while the C++ version is the target GDExtension implementation for the final integrated project.

## Integration with teammates

Navigator: call `GameManager.perform_movement(unit_id)`.
Combat Specialist: call `GameManager.perform_standard_attack(unit_id)`.
Combat/Tactician: call `GameManager.use_ultimate(unit_id)`.
Everyone: use `GameManager.end_turn()` through the central HUD.

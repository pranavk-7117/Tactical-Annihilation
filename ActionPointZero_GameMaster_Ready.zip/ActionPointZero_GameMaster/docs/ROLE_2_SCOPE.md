# Role 2 — The Game Master

Source basis: supplied project/game-design PDFs.

Owned C++ responsibilities:
- GameManager state machine
- Turn tracking
- 5-AP pool logic
- Win-condition checks

Owned Godot responsibilities:
- Main Menu
- Match HUD (AP gems / AP display and round counter)
- End Turn control
- Connecting UI controls to GameManager
- Roster and result screens in the prototype

Core rules encoded here:
- 5 AP per active player turn
- No unit can spend more than 3 AP in one turn
- Movement 1 AP
- Standard Attack 2 AP
- Ultimate 3 AP
- Ultimates unavailable through Round 3
- One Ultimate per turn after unlock
- Total Tactical Annihilation ends the match

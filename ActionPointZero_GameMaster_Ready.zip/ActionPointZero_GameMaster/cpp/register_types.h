#ifndef ACTION_POINT_ZERO_REGISTER_TYPES_H
#define ACTION_POINT_ZERO_REGISTER_TYPES_H

#include <godot_cpp/core/class_db.hpp>

using namespace godot;

void initialize_game_master_module(ModuleInitializationLevel p_level);
void uninitialize_game_master_module(ModuleInitializationLevel p_level);

#endif

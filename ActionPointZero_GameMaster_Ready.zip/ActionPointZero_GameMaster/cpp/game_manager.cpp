#include "game_manager.h"

#include <godot_cpp/core/class_db.hpp>
#include <godot_cpp/variant/array.hpp>
#include <godot_cpp/variant/utility_functions.hpp>

using namespace godot;

void GameManager::_bind_methods() {
    ClassDB::bind_method(D_METHOD("start_match"), &GameManager::start_match);
    ClassDB::bind_method(D_METHOD("end_turn"), &GameManager::end_turn);
    ClassDB::bind_method(D_METHOD("spend_ap", "amount"), &GameManager::spend_ap);
    ClassDB::bind_method(D_METHOD("spend_unit_ap", "unit_id", "amount"), &GameManager::spend_unit_ap);
    ClassDB::bind_method(D_METHOD("get_action_points"), &GameManager::get_action_points);
    ClassDB::bind_method(D_METHOD("get_current_player"), &GameManager::get_current_player);
    ClassDB::bind_method(D_METHOD("get_round_number"), &GameManager::get_round_number);
    ClassDB::bind_method(D_METHOD("get_unit_ap_spent", "unit_id"), &GameManager::get_unit_ap_spent);
    ClassDB::bind_method(D_METHOD("can_use_ultimate"), &GameManager::can_use_ultimate);
    ClassDB::bind_method(D_METHOD("use_ultimate", "unit_id"), &GameManager::use_ultimate);
    ClassDB::bind_method(D_METHOD("register_unit", "unit_id", "player_id"), &GameManager::register_unit);
    ClassDB::bind_method(D_METHOD("set_unit_alive", "unit_id", "alive"), &GameManager::set_unit_alive);
    ClassDB::bind_method(D_METHOD("is_unit_alive", "unit_id"), &GameManager::is_unit_alive);
    ClassDB::bind_method(D_METHOD("check_win_condition"), &GameManager::check_win_condition);
    ClassDB::bind_method(D_METHOD("is_game_over"), &GameManager::is_game_over);
    ClassDB::bind_method(D_METHOD("get_winner"), &GameManager::get_winner);

    ADD_SIGNAL(MethodInfo("ap_changed", PropertyInfo(Variant::INT, "current_ap")));
    ADD_SIGNAL(MethodInfo("turn_changed",
        PropertyInfo(Variant::INT, "player"),
        PropertyInfo(Variant::INT, "round")));
    ADD_SIGNAL(MethodInfo("game_over", PropertyInfo(Variant::INT, "winner")));
    ADD_SIGNAL(MethodInfo("ultimate_status_changed", PropertyInfo(Variant::BOOL, "available")));
}

void GameManager::start_match() {
    current_player = 1;
    round_number = 1;
    action_points = 5;
    ultimate_used_this_turn = false;
    game_over = false;
    winner = 0;
    unit_ap_spent.clear();
    unit_alive.clear();
    unit_owner.clear();

    const String names[] = {"Sniper", "Infantry", "Cavalry", "Medic", "Chemist"};
    for (int i = 0; i < 5; ++i) {
        register_unit("P1_" + names[i], 1);
        register_unit("P2_" + names[i], 2);
    }

    emit_signal("ap_changed", action_points);
    emit_signal("turn_changed", current_player, round_number);
    emit_signal("ultimate_status_changed", can_use_ultimate());
}

bool GameManager::spend_ap(int amount) {
    if (game_over || amount <= 0 || action_points < amount) {
        return false;
    }
    action_points -= amount;
    emit_signal("ap_changed", action_points);
    emit_signal("ultimate_status_changed", can_use_ultimate());
    return true;
}

bool GameManager::spend_unit_ap(String unit_id, int amount) {
    if (game_over || amount <= 0 || !unit_alive.has(unit_id) || !unit_owner.has(unit_id)) {
        return false;
    }
    if ((int)unit_owner[unit_id] != current_player) {
        return false;
    }
    int used = get_unit_ap_spent(unit_id);
    if (used + amount > MAX_UNIT_AP || action_points < amount) {
        return false;
    }
    action_points -= amount;
    unit_ap_spent[unit_id] = used + amount;
    emit_signal("ap_changed", action_points);
    emit_signal("ultimate_status_changed", can_use_ultimate());
    return true;
}

int GameManager::get_action_points() const { return action_points; }
int GameManager::get_current_player() const { return current_player; }
int GameManager::get_round_number() const { return round_number; }

int GameManager::get_unit_ap_spent(String unit_id) const {
    if (!unit_ap_spent.has(unit_id)) return 0;
    return (int)unit_ap_spent[unit_id];
}

bool GameManager::can_use_ultimate() {
    return !game_over && round_number >= 4 && !ultimate_used_this_turn && action_points >= ULTIMATE_AP;
}

bool GameManager::use_ultimate(String unit_id) {
    if (!can_use_ultimate() || !unit_owner.has(unit_id)) return false;
    int used = get_unit_ap_spent(unit_id);
    if (used + ULTIMATE_AP > MAX_UNIT_AP) return false;
    if (!spend_unit_ap(unit_id, ULTIMATE_AP)) return false;
    ultimate_used_this_turn = true;
    emit_signal("ultimate_status_changed", false);
    return true;
}

void GameManager::end_turn() {
    if (game_over) return;
    if (current_player == 1) {
        current_player = 2;
    } else {
        current_player = 1;
        ++round_number;
    }
    action_points = 5;
    unit_ap_spent.clear();
    ultimate_used_this_turn = false;
    emit_signal("ap_changed", action_points);
    emit_signal("turn_changed", current_player, round_number);
    emit_signal("ultimate_status_changed", can_use_ultimate());
}

void GameManager::register_unit(String unit_id, int player_id) {
    unit_alive[unit_id] = true;
    unit_owner[unit_id] = player_id;
}

void GameManager::set_unit_alive(String unit_id, bool alive) {
    if (!unit_alive.has(unit_id)) return;
    unit_alive[unit_id] = alive;
    check_win_condition();
}

bool GameManager::is_unit_alive(String unit_id) {
    return unit_alive.has(unit_id) && (bool)unit_alive[unit_id];
}

void GameManager::check_win_condition() {
    if (game_over) return;
    bool p1_alive = false;
    bool p2_alive = false;

    Array keys = unit_alive.keys();
    for (int i = 0; i < keys.size(); ++i) {
        String id = keys[i];
        if (!is_unit_alive(id) || !unit_owner.has(id)) continue;
        int owner = (int)unit_owner[id];
        if (owner == 1) p1_alive = true;
        if (owner == 2) p2_alive = true;
    }

    if (p1_alive && !p2_alive) {
        game_over = true;
        winner = 1;
        emit_signal("game_over", winner);
    } else if (p2_alive && !p1_alive) {
        game_over = true;
        winner = 2;
        emit_signal("game_over", winner);
    }
}

bool GameManager::is_game_over() const { return game_over; }
int GameManager::get_winner() const { return winner; }

#ifndef GAME_MANAGER_H
#define GAME_MANAGER_H

#include <godot_cpp/classes/node.hpp>
#include <godot_cpp/variant/dictionary.hpp>
#include <godot_cpp/variant/string.hpp>

namespace godot {

class GameManager : public Node {
    GDCLASS(GameManager, Node)

private:
    int current_player = 1;
    int round_number = 1;
    int action_points = 5;
    static const int MAX_UNIT_AP = 3;
    static const int ULTIMATE_AP = 3;
    bool ultimate_used_this_turn = false;
    bool game_over = false;
    int winner = 0;
    Dictionary unit_ap_spent;
    Dictionary unit_alive;
    Dictionary unit_owner;

protected:
    static void _bind_methods();

public:
    GameManager() = default;
    ~GameManager() = default;

    void start_match();
    void end_turn();

    bool spend_ap(int amount);
    bool spend_unit_ap(String unit_id, int amount);
    int get_action_points() const;
    int get_current_player() const;
    int get_round_number() const;
    int get_unit_ap_spent(String unit_id) const;

    bool can_use_ultimate();
    bool use_ultimate(String unit_id);

    void register_unit(String unit_id, int player_id);
    void set_unit_alive(String unit_id, bool alive);
    bool is_unit_alive(String unit_id);

    void check_win_condition();
    bool is_game_over() const;
    int get_winner() const;
};

}

#endif
